local _ = require("gettext")
return {
    name = "controlcentre",
    fullname = _("Control centre"),
    description = _([[A Kindle-style quick settings panel: swipe down from the top edge for Wi-Fi, dark mode, lock screen, sync, all settings, and brightness / warmth sliders.

Extracted from kindleui.koplugin. Disable that plugin's control centre (or the plugin) if both are installed.]]),
    version = "0.1.0",
}
