-- Settings for the control centre. Stored in KOReader's global settings.
local Blitbuffer = require("ffi/blitbuffer")
local Device = require("device")
local lfs = require("libs/libkoreader-lfs")

local Settings = {}

local KEY = "controlcentre_text_color"
Settings.DEFAULT_COLOR = "#000000"

--- "#RRGGBB" or "#RGB" (the # is optional) -> "#rrggbb", or nil if it is not hex.
function Settings.normalize(text)
    text = tostring(text or ""):gsub("%s", ""):gsub("^#", "")
    if text:match("^%x%x%x$") then
        text = text:gsub(".", function(c) return c .. c end)
    end
    if text:match("^%x%x%x%x%x%x$") then
        return "#" .. text:lower()
    end
    return nil
end

function Settings.getColorHex()
    return Settings.normalize(G_reader_settings:readSetting(KEY)) or Settings.DEFAULT_COLOR
end

function Settings.setColorHex(hex)
    G_reader_settings:saveSetting(KEY, Settings.normalize(hex) or Settings.DEFAULT_COLOR)
end

--- The text colour as a Blitbuffer colour. E-ink panels without colour get the
-- hex's grey level.
function Settings.getTextColor()
    local hex = Settings.getColorHex()
    local r = tonumber(hex:sub(2, 3), 16)
    local g = tonumber(hex:sub(4, 5), 16)
    local b = tonumber(hex:sub(6, 7), 16)
    if Device.screen:isColorEnabled() and Blitbuffer.ColorRGB32 then
        return Blitbuffer.ColorRGB32(r, g, b, 0xFF)
    end
    return Blitbuffer.Color8(math.floor(0.299 * r + 0.587 * g + 0.114 * b + 0.5))
end

-- ── Buttons ─────────────────────────────────────────────────────────────────
-- The panel's buttons, in order. Each entry is either
--   { builtin = "wifi" }                one of the built-in buttons, or
--   { action = <Dispatcher settings> }  any KOReader action,
-- with an optional `label`. An entry that has an action runs that action even if
-- it also names a built-in, which is how a built-in button is re-assigned.
local BUTTONS = "controlcentre_buttons"

Settings.BUILTIN_ORDER = { "wifi", "darkmode", "lock", "sync", "settings" }

function Settings.hasAction(entry)
    return type(entry.action) == "table" and next(entry.action) ~= nil
end

function Settings.getButtons()
    local list = G_reader_settings:readSetting(BUTTONS)
    if type(list) ~= "table" then
        list = {}
        for _idx, id in ipairs(Settings.BUILTIN_ORDER) do
            table.insert(list, { builtin = id })
        end
        -- Actions added by earlier versions.
        local legacy = G_reader_settings:readSetting("controlcentre_actions")
        for _idx, action in ipairs(type(legacy) == "table" and legacy or {}) do
            table.insert(list, { action = action })
        end
        G_reader_settings:saveSetting(BUTTONS, list)
    end
    -- Drop entries that ended up with nothing to do (a chooser that was opened
    -- and backed out of).
    for i = #list, 1, -1 do
        local entry = list[i]
        if type(entry) ~= "table" or not (entry.builtin or Settings.hasAction(entry)) then
            table.remove(list, i)
        end
    end
    return list
end

-- ── Icons ───────────────────────────────────────────────────────────────────
-- SVGs in the plugin's icons/ folder; an entry's `icon` is the file name
-- without ".svg".
local ICON_DIR = (debug.getinfo(1, "S").source:match("^@(.*)/[^/]*$") or ".") .. "/icons/"

function Settings.iconPath(name)
    if type(name) ~= "string" or name == "" then return nil end
    local path = ICON_DIR .. name .. ".svg"
    return lfs.attributes(path, "mode") == "file" and path or nil
end

function Settings.listIcons()
    local names = {}
    if lfs.attributes(ICON_DIR, "mode") == "directory" then
        for f in lfs.dir(ICON_DIR) do
            local name = f:match("^([^.].*)%.svg$")
            if name then table.insert(names, name) end
        end
    end
    table.sort(names)
    return names
end

function Settings.resetButtons()
    G_reader_settings:saveSetting(BUTTONS, nil)
    G_reader_settings:saveSetting("controlcentre_actions", nil)
end

return Settings
