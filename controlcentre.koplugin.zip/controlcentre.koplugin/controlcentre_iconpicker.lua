-- Popup grid of the icons in the plugin's icons/ folder, with their names.
local Blitbuffer = require("ffi/blitbuffer")
local Device = require("device")
local Font = require("ui/font")
local Geom = require("ui/geometry")
local GestureRange = require("ui/gesturerange")
local IconWidget = require("ui/widget/iconwidget")
local InputContainer = require("ui/widget/container/inputcontainer")
local TextWidget = require("ui/widget/textwidget")
local UIManager = require("ui/uimanager")
local CCSettings = require("controlcentre_settings")
local _ = require("gettext")

local Screen = Device.screen
local COLS, ROWS = 4, 4

local IconPicker = InputContainer:extend{
    current = nil,  -- name of the icon in use
    on_pick = nil,  -- function(name or nil); nil means "default"
}

function IconPicker:init()
    self.names = CCSettings.listIcons()
    self.per_page = COLS * ROWS
    self.pages = math.max(1, math.ceil(#self.names / self.per_page))
    self.page = 1
    for i, name in ipairs(self.names) do
        if name == self.current then self.page = math.ceil(i / self.per_page) end
    end

    local sw, sh = Screen:getWidth(), Screen:getHeight()
    local w, h = math.floor(sw * 0.94), math.floor(sh * 0.8)
    self.box = Geom:new{ x = math.floor((sw - w) / 2), y = math.floor((sh - h) / 2), w = w, h = h }
    self.dimen = Geom:new{ x = 0, y = 0, w = sw, h = sh }
    self.header_h = Screen:scaleBySize(48)
    self.footer_h = Screen:scaleBySize(56)
    self.cell_w = math.floor(w / COLS)
    self.cell_h = math.floor((h - self.header_h - self.footer_h) / ROWS)
    self.icon_size = math.floor(math.min(self.cell_w, self.cell_h) * 0.34)
    self.face = Font:getFace("cfont", 16)
    self.footer = { "default", "prev", "page", "next", "close" }
    self.ges_events = {
        TapPicker = { GestureRange:new{ ges = "tap", range = self.dimen } },
        SwipePicker = { GestureRange:new{ ges = "swipe", range = self.dimen } },
    }
end

function IconPicker:_text(text, max_w)
    return TextWidget:new{ text = text, face = self.face, max_width = max_w, padding = 0 }
end

function IconPicker:_freePage()
    for _i, wd in ipairs(self.live or {}) do wd:free() end
    self.live = {}
end

local function border(bb, x, y, w, h, t)
    bb:paintRect(x, y, w, t, Blitbuffer.COLOR_BLACK)
    bb:paintRect(x, y + h - t, w, t, Blitbuffer.COLOR_BLACK)
    bb:paintRect(x, y, t, h, Blitbuffer.COLOR_BLACK)
    bb:paintRect(x + w - t, y, t, h, Blitbuffer.COLOR_BLACK)
end

function IconPicker:paintTo(bb)
    self:_freePage()
    local b = self.box
    bb:paintRect(b.x, b.y, b.w, b.h, Blitbuffer.COLOR_WHITE)
    border(bb, b.x, b.y, b.w, b.h, 2)

    local function put(widget, cx, cy)
        table.insert(self.live, widget)
        local s = widget:getSize()
        widget:paintTo(bb, cx - math.floor(s.w / 2), cy - math.floor(s.h / 2))
    end

    put(self:_text(_("Choose an icon"), b.w - 20), b.x + math.floor(b.w / 2), b.y + math.floor(self.header_h / 2))

    local first = (self.page - 1) * self.per_page
    for n = 1, self.per_page do
        local name = self.names[first + n]
        if not name then break end
        local col, row = (n - 1) % COLS, math.floor((n - 1) / COLS)
        local cx = b.x + col * self.cell_w
        local cy = b.y + self.header_h + row * self.cell_h
        local mid = cx + math.floor(self.cell_w / 2)
        local icon_cy = cy + math.floor(self.cell_h * 0.36)
        if name == self.current then
            local box = self.icon_size + Screen:scaleBySize(16)
            bb:paintBorder(mid - math.floor(box / 2), icon_cy - math.floor(box / 2), box, box,
                3, Blitbuffer.COLOR_BLACK, math.floor(box / 5))
        end
        put(IconWidget:new{ file = CCSettings.iconPath(name), width = self.icon_size, height = self.icon_size },
            mid, icon_cy)
        put(self:_text(name, self.cell_w - 8), mid, cy + math.floor(self.cell_h * 0.82))
    end

    local labels = { default = _("Default"), prev = "<", next = ">", close = _("Close"),
                     page = self.page .. "/" .. self.pages }
    local slot_w = math.floor(b.w / #self.footer)
    local fy = b.y + b.h - self.footer_h
    bb:paintRect(b.x, fy, b.w, 1, Blitbuffer.COLOR_BLACK)
    for i, id in ipairs(self.footer) do
        put(self:_text(labels[id], slot_w - 8), b.x + (i - 1) * slot_w + math.floor(slot_w / 2),
            fy + math.floor(self.footer_h / 2))
    end
end

function IconPicker:_redraw()
    UIManager:setDirty(self, function() return "ui", self.box end)
end

function IconPicker:onSwipePicker(_arg, ges)
    local d = ges.direction
    local step = (d == "west" or d == "north") and 1 or ((d == "east" or d == "south") and -1 or 0)
    local page = math.max(1, math.min(self.pages, self.page + step))
    if step ~= 0 and page ~= self.page then
        self.page = page
        self:_redraw()
    end
    return true
end

function IconPicker:onTapPicker(_arg, ges)
    local b, pos = self.box, ges.pos
    if not b:contains(pos) then
        UIManager:close(self)
        return true
    end
    local fy = b.y + b.h - self.footer_h
    if pos.y >= fy then
        local id = self.footer[math.floor((pos.x - b.x) / (b.w / #self.footer)) + 1]
        if id == "close" then
            UIManager:close(self)
        elseif id == "default" then
            UIManager:close(self)
            if self.on_pick then self.on_pick(nil) end
        elseif id == "prev" and self.page > 1 then
            self.page = self.page - 1
            self:_redraw()
        elseif id == "next" and self.page < self.pages then
            self.page = self.page + 1
            self:_redraw()
        end
        return true
    end
    local ry = pos.y - b.y - self.header_h
    if ry >= 0 then
        local col = math.floor((pos.x - b.x) / self.cell_w)
        local row = math.floor(ry / self.cell_h)
        local name = self.names[(self.page - 1) * self.per_page + row * COLS + col + 1]
        if name and col < COLS and row < ROWS then
            UIManager:close(self)
            if self.on_pick then self.on_pick(name) end
        end
    end
    return true
end

function IconPicker:onCloseWidget()
    self:_freePage()
    UIManager:setDirty(nil, "ui")
end

return IconPicker
