# controlcentre.koplugin

Kindle-style quick settings panel for KOReader, split out of
[kindleui.koplugin](https://github.com/hhoangg/kindleui.koplugin).

Swipe (or pull) down from the top edge in the reader, file manager, or the
bookshelf home screen. Also available as a gesture/Dispatcher action: **Control centre**.

- Replaces the top-edge swipe and tap that open the main menu. All Settings opens the main menu (Modern Menu if installed)
- Toggles: Wi-Fi, Dark Mode, Lock Screen, Sync, All Settings (opens KOReader's menu)
- Sliders follow the finger live (throttled partial redraws, like LiveLight)
- Sliders: Brightness, Warmth (with AutoWarmth schedule shortcut)

## Install
Copy `controlcentre.koplugin` into KOReader's `plugins/` folder and restart.

If `kindleui.koplugin` is also installed, disable it (or this one): both claim the
same top-edge swipe.

Sync fires the `XtreaderSync` event, so it only does something if a plugin handles it.

## Buttons
Main menu > More tools > Control centre. Every button, built-in or added, can be edited:
tap it to change its action (any KOReader action, the same list gestures use), rename it,
choose its icon from a visual picker (any SVG in the plugin's `icons/` folder; drop more in to add them),
move it up or down, or remove it. "Add button" adds a new one; "Restore default buttons"
resets the row. Buttons wrap onto new rows of five. Removed or added buttons show in the
list the next time you open the menu.

## Text colour
Main menu > More tools > Control centre > Text colour. Enter a hex code (#RRGGBB or #RGB).
On greyscale e-ink screens the colour is shown as its grey level.
