--[[--
Control centre: a Kindle-style quick settings panel, opened by swiping down from
the top edge (reader, file manager and the bookshelf home screen).
]]
local Device = require("device")
local Dispatcher = require("dispatcher")
local Event = require("ui/event")
local UIManager = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local InfoMessage = require("ui/widget/infomessage")
local InputDialog = require("ui/widget/inputdialog")
local CCSettings = require("controlcentre_settings")
local logger = require("logger")
local _ = require("gettext")

local ControlCentre = WidgetContainer:extend{
    name = "controlcentre",
    is_doc_only = false, -- device-level: also wanted on the file manager
}

-- Stock zones that would otherwise take the same gesture (readermenu.lua).
local TOP_OVERRIDES = {
    "readermenu_ext_swipe", "readermenu_swipe",
    "readermenu_ext_pan", "readermenu_pan",
    "rolling_swipe", "paging_swipe",
    "rolling_pan", "paging_pan",
}

local TOP_TAP_OVERRIDES = {
    "readermenu_ext_tap", "readermenu_tap", "tap_forward", "tap_backward",
}

-- Fullscreen home screens that cover the file manager and need the zone grafted
-- onto them, by the `name` they declare.
local HOME_SCREEN_WIDGETS = { bookshelf = true }

local function zoneRatio(key, fallback)
    local v = G_defaults and G_defaults:readSetting(key)
    if type(v) == "table" and v.w and v.h then
        return { ratio_x = v.x, ratio_y = v.y, ratio_w = v.w, ratio_h = v.h }
    end
    return fallback
end

-- The stock menu zones are the top 1/8 (and 1/5 in the middle) of the screen;
-- the control centre only listens in a thinner strip along the very top.
local MAX_ZONE_H = 0.05

local function topZones()
    local top = zoneRatio("DTAP_ZONE_MENU", { ratio_x = 0, ratio_y = 0, ratio_w = 1, ratio_h = 1/8 })
    local top_ext = zoneRatio("DTAP_ZONE_MENU_EXT", { ratio_x = 1/4, ratio_y = 0, ratio_w = 2/4, ratio_h = 1/5 })
    top = { ratio_x = top.ratio_x, ratio_y = top.ratio_y, ratio_w = top.ratio_w,
            ratio_h = math.min(top.ratio_h, MAX_ZONE_H) }
    top_ext = { ratio_x = top_ext.ratio_x, ratio_y = top_ext.ratio_y, ratio_w = top_ext.ratio_w,
                ratio_h = math.min(top_ext.ratio_h, MAX_ZONE_H) }
    return top, top_ext
end

function ControlCentre:init()
    Dispatcher:registerAction("controlcentre_show", {
        category = "none",
        event = "ShowControlCentre",
        title = _("Control centre"),
        general = true,
    })
    self:setupTouchZones()
    if self.ui and self.ui.menu then self.ui.menu:registerToMainMenu(self) end
    -- Plugins load alphabetically, so Modern Menu does not exist yet: wait.
    UIManager:nextTick(function()
        UIManager:nextTick(function() self:patchModernMenu() end)
    end)

    -- Used to notice when the bookshelf home screen is on top (see onInputEvent).
    if not self._input_hook_registered
       and UIManager.event_hook and UIManager.event_hook.registerWidget then
        UIManager.event_hook:registerWidget("InputEvent", self)
        self._input_hook_registered = true
    end
end

local BUILTIN_NAMES = {
    wifi = _("Wi-Fi"), darkmode = _("Dark Mode"), lock = _("Lock Screen"),
    sync = _("Sync"), settings = _("All Settings"),
}

local function buttonName(entry)
    if type(entry.label) == "string" and entry.label ~= "" then return entry.label end
    if CCSettings.hasAction(entry) then
        local ok, text = pcall(require("dispatcher").menuTextFunc, require("dispatcher"), entry.action)
        return ok and text or _("Action")
    end
    return BUILTIN_NAMES[entry.builtin] or _("Button")
end

--- Main menu > More tools > Control centre. Every button, built-in or added, can
-- be given any KOReader action (the list gestures use), renamed, moved or removed.
function ControlCentre:addToMainMenu(menu_items)
    menu_items.controlcentre = {
        text = _("Control Centre"),
        sorting_hint = "more_tools",
        sub_item_table_func = function()
            local Dispatcher = require("dispatcher")
            local list = CCSettings.getButtons()
            local items = {}
            table.insert(items, {
                text_func = function()
                    return _("Text colour") .. ": " .. CCSettings.getColorHex()
                end,
                keep_menu_open = true,
                callback = function(touchmenu_instance) self:_editColor(touchmenu_instance) end,
            })
            table.insert(items, {
                text = _("Add button"),
                -- Built when opened: the new, empty entry is what the chooser
                -- fills in. Backing out leaves it empty and it is dropped.
                sub_item_table_func = function()
                    local entry = {}
                    table.insert(list, entry)
                    local sub = {}
                    Dispatcher:addSubMenu(self, sub, entry, "action")
                    return sub
                end,
            })
            for i = 1, #list do
                table.insert(items, {
                    text_func = function()
                        local entry = list[i]
                        return entry and (i .. ". " .. buttonName(entry)) or "-"
                    end,
                    sub_item_table_func = function() return self:_buttonMenu(list, i) end,
                    separator = (i == 1) or nil,
                })
            end
            table.insert(items, {
                text = _("Restore default buttons"),
                callback = function(touchmenu_instance)
                    CCSettings.resetButtons()
                    touchmenu_instance:closeMenu()
                end,
                separator = true,
            })
            return items
        end,
    }
end

function ControlCentre:_buttonMenu(list, i)
    local Dispatcher = require("dispatcher")
    local entry = list[i]
    if not entry then return {} end
    local action_menu = {}
    Dispatcher:addSubMenu(self, action_menu, entry, "action")
    local items = {
        {
            text_func = function()
                return _("Action") .. ": " ..
                    (CCSettings.hasAction(entry) and buttonName({ action = entry.action })
                     or BUILTIN_NAMES[entry.builtin] or _("none"))
            end,
            sub_item_table = action_menu,
        },
        {
            text_func = function()
                return _("Icon") .. ": " .. (CCSettings.iconPath(entry.icon) and entry.icon or _("default"))
            end,
            keep_menu_open = true,
            callback = function(touchmenu_instance)
                UIManager:show(require("controlcentre_iconpicker"):new{
                    current = entry.icon,
                    on_pick = function(name)
                        entry.icon = name
                        if touchmenu_instance then touchmenu_instance:updateItems() end
                    end,
                })
            end,
        },
        {
            text = _("Rename"),
            keep_menu_open = true,
            callback = function(touchmenu_instance) self:_renameButton(entry, touchmenu_instance) end,
        },
        {
            text = _("Move up"),
            enabled_func = function() return i > 1 end,
            callback = function(touchmenu_instance)
                list[i], list[i - 1] = list[i - 1], list[i]
                touchmenu_instance:backToUpperMenu()
            end,
        },
        {
            text = _("Move down"),
            enabled_func = function() return i < #list end,
            callback = function(touchmenu_instance)
                list[i], list[i + 1] = list[i + 1], list[i]
                touchmenu_instance:backToUpperMenu()
            end,
        },
    }
    if entry.builtin then
        table.insert(items, {
            text = _("Back to built-in action"),
            enabled_func = function() return CCSettings.hasAction(entry) end,
            callback = function(touchmenu_instance)
                entry.action = nil
                touchmenu_instance:backToUpperMenu()
            end,
        })
    end
    table.insert(items, {
        text = _("Remove button"),
        callback = function(touchmenu_instance)
            table.remove(list, i)
            -- The list of buttons is built when the menu opens.
            touchmenu_instance:closeMenu()
        end,
    })
    return items
end

function ControlCentre:_renameButton(entry, touchmenu_instance)
    local dialog
    dialog = InputDialog:new{
        title = _("Button label (empty for the default)"),
        input = entry.label or "",
        buttons = {{
            { text = _("Cancel"), callback = function() UIManager:close(dialog) end },
            { text = _("Save"), is_enter_default = true, callback = function()
                local text = dialog:getInputText()
                entry.label = (text ~= "" and text) or nil
                UIManager:close(dialog)
                if touchmenu_instance then touchmenu_instance:updateItems() end
            end },
        }},
    }
    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

function ControlCentre:_editColor(touchmenu_instance)
    local dialog
    dialog = InputDialog:new{
        title = _("Text colour (hex, e.g. #1a1a1a)"),
        input = CCSettings.getColorHex(),
        buttons = {{
            { text = _("Cancel"), callback = function() UIManager:close(dialog) end },
            { text = _("Reset"), callback = function()
                CCSettings.setColorHex(CCSettings.DEFAULT_COLOR)
                UIManager:close(dialog)
                if touchmenu_instance then touchmenu_instance:updateItems() end
            end },
            { text = _("Save"), is_enter_default = true, callback = function()
                local hex = CCSettings.normalize(dialog:getInputText())
                if not hex then
                    UIManager:show(InfoMessage:new{ text = _("Not a valid hex colour. Use #RRGGBB or #RGB.") })
                    return
                end
                CCSettings.setColorHex(hex)
                UIManager:close(dialog)
                if touchmenu_instance then touchmenu_instance:updateItems() end
            end },
        }},
    }
    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

--- Modern Menu opens itself from top-edge gestures by two routes that run before
-- touch zones get a look: the file manager's handleEvent wrapper, and the
-- onSwipeShowMenu / onTapShowMenu wrappers. Both end in its
-- `_openMenuFromGesture`, which is NOT used when the menu is opened explicitly
-- (onShowMenu, key, Dispatcher), so redirecting just that method makes the
-- gesture open the control centre and leaves "All Settings" opening Modern Menu.
function ControlCentre:patchModernMenu()
    local mm = self.ui and self.ui.modern_menu
    if not mm then
        local ok, PluginLoader = pcall(require, "pluginloader")
        mm = ok and PluginLoader.getPluginInstance and PluginLoader:getPluginInstance("modern_menu") or nil
    end
    if type(mm) ~= "table" or mm._controlcentre_patched then return end
    local original = mm._openMenuFromGesture
    if type(original) ~= "function" then return end
    mm._controlcentre_patched = true
    mm._openMenuFromGesture = function(mm_self, menu, ges)
        return self:onShowControlCentre(ges and ges.ges == "pan")
    end
    logger.info("controlcentre: Modern Menu top-edge gestures redirected")
end

function ControlCentre:onReaderReady() self:setupTouchZones() self:patchModernMenu() end
function ControlCentre:onSetDimensions() self:setupTouchZones() end

--- Swipe or pan south from the top band. A pan is reported while the finger is
-- still down, so the panel is told which one opened it.
function ControlCentre:_zones(prefix, overrides)
    local top, top_ext = topZones()
    
    local function handler(ges)
        if ges.direction ~= "south" then return false end
        return self:onShowControlCentre(ges.ges == "pan")
    end
    local zones = {}
    for _idx, g in ipairs({ "swipe", "pan" }) do
        zones[#zones + 1] = { id = prefix .. "cc_" .. g, ges = g,
                              screen_zone = top, overrides = overrides, handler = handler }
        zones[#zones + 1] = { id = prefix .. "cc_ext_" .. g, ges = g,
                              screen_zone = top_ext, overrides = overrides, handler = handler }
    end
    return zones
end

function ControlCentre:setupTouchZones()
    if not Device:isTouchDevice() then return end
    local ui = self.ui
    if not (ui and ui.registerTouchZones) then return end

    -- Release the copy on a previous home screen before the zones are rebuilt.
    if self._home_host and self._home_zones and self._home_host.unRegisterTouchZones then
        pcall(self._home_host.unRegisterTouchZones, self._home_host, self._home_zones)
    end
    self._home_host, self._home_seen = nil, nil

    local zones = self:_zones("controlcentre_", TOP_OVERRIDES)
    local top, top_ext = topZones()
    
    local function tap() return self:onShowControlCentre(false) end
    zones[#zones + 1] = { id = "controlcentre_tap", ges = "tap", screen_zone = top,
                          overrides = TOP_TAP_OVERRIDES, handler = tap }
    zones[#zones + 1] = { id = "controlcentre_ext_tap", ges = "tap", screen_zone = top_ext,
                          overrides = TOP_TAP_OVERRIDES, handler = tap }
    ui:registerTouchZones(zones)
    -- The file manager's own top-edge tap lives on ui.menu (filemanagermenu.lua),
    -- in a different zone graph: replace it by id rather than override it.
    local fm_menu = not ui.document and ui.menu
    if fm_menu and fm_menu.registerTouchZones then
        pcall(fm_menu.registerTouchZones, fm_menu, {
            { id = "filemanager_tap", ges = "tap", screen_zone = top, handler = tap },
            { id = "filemanager_ext_tap", ges = "tap", screen_zone = top_ext, handler = tap },
        })
    end
    self._home_zones = self:_zones("controlcentre_home_", nil)
    logger.info("controlcentre: zones registered on", ui.document and "ReaderUI" or "FileManager")
end

--- Grafts the zones onto the bookshelf home screen when it becomes topmost.
-- Runs once per input frame; it is one table compare unless the top widget changed.
function ControlCentre:onInputEvent()
    if not self._home_zones then return end
    local top = UIManager:getTopmostVisibleWidget()
    if top == self._home_seen then return end
    self._home_seen = top
    if type(top) ~= "table" or not HOME_SCREEN_WIDGETS[top.name] then return end
    if not top.covers_fullscreen or type(top.registerTouchZones) ~= "function" then return end
    if pcall(top.registerTouchZones, top, self._home_zones) then
        self._home_host = top
    end
end

function ControlCentre:onShowControlCentre(finger_still_down)
    local live = self._panel
    if live and UIManager:isWidgetShown(live) then return true end

    local ok, Panel = pcall(require, "controlcentre_panel")
    if not ok then
        logger.warn("controlcentre: failed to load panel:", tostring(Panel))
        return false
    end
    local built, panel = pcall(function() return Panel:new{ ui = self.ui } end)
    if not built or not panel then
        logger.warn("controlcentre: failed to build panel:", tostring(panel))
        return false
    end
    self._panel = panel
    -- Name the refresh region: the panel is only the top band of the screen.
    UIManager:show(panel, "ui", panel.dimen)

    -- Opened mid-stroke: ignore the rest of that stroke so the sliders do not
    -- grab it.
    if finger_still_down and panel.armAfterOpen then panel:armAfterOpen() end
    -- Stop any pan-scroll the swipe started.
    if self.ui and self.ui.handleEvent then
        self.ui:handleEvent(Event:new("HandledAsSwipe"))
    end
    return true
end

return ControlCentre
