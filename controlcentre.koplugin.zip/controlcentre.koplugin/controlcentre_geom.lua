-- Proportions of Kindle's 1236x1648 panel, scaled to the current screen.
local Device = require("device")
local Screen = Device.screen

local REF_W, REF_H = 1236, 1648

local Geom = { PANEL = 1331 / REF_H }

function Geom.h(band) return math.floor(Screen:getHeight() * band) end
function Geom.x(px) return math.floor(Screen:getWidth() * px / REF_W) end
function Geom.y(px) return math.floor(Screen:getHeight() * px / REF_H) end

return Geom
